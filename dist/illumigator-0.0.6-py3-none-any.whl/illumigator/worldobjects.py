from abc import abstractmethod
import random
import arcade
import math
import numpy

import illumigator.light as light
from illumigator import util as util
import illumigator.geometry as geometry


class WorldObject:
    _position: numpy.ndarray
    _rotation_angle: float
    _is_interactable: bool
    _is_receiver: bool
    _geometry_segments: list[geometry.Geometry]

    _sprite_list: arcade.SpriteList
    color: tuple[int, int, int]

      
    def __init__(self, position: numpy.ndarray, dimensions: numpy.ndarray, rotation_angle: float, sprite_info: tuple, color=random.choice(
        util.COLORS), is_interactable=False, is_receiver=False):
        self._position = position
        self._rotation_angle = rotation_angle
        self._is_interactable = is_interactable
        self._is_receiver = is_receiver
        self._geometry_segments = []

        self._sprite_list = arcade.SpriteList()
        self.color = color

        sprite_path, sprite_scale, sprite_width, sprite_height = sprite_info

        side_lengths = numpy.array([
            sprite_width  * sprite_scale * dimensions[0],
            sprite_height * sprite_scale * dimensions[1]
        ])
        axis1_norm = numpy.array([math.cos(rotation_angle), math.sin(rotation_angle)])
        axis2_norm = numpy.array([-math.sin(rotation_angle), math.cos(rotation_angle)])
        axis1 = 0.5 * side_lengths[0] * axis1_norm
        axis2 = 0.5 * side_lengths[1] * axis2_norm
        self._geometry_segments = [
            geometry.Line(position - axis1 - axis2, position - axis1 + axis2),
            geometry.Line(position - axis1 + axis2, position + axis1 + axis2),
            geometry.Line(position + axis1 + axis2, position + axis1 - axis2),
            geometry.Line(position + axis1 - axis2, position - axis1 - axis2),
        ]

        for col in range(int(dimensions[0])):
            for row in range(int(dimensions[1])):
                sprite_center = (position-axis1-axis2) + sprite_scale * ((sprite_width*(col+0.5)*axis1_norm) + (sprite_height*(row+0.5)*axis2_norm))

                self._sprite_list.append( arcade.Sprite(
                    sprite_path, sprite_scale, image_width=sprite_width, image_height=sprite_height,
                    center_x=sprite_center[0], center_y=sprite_center[1],
                    angle=numpy.rad2deg(rotation_angle), hit_box_algorithm="Simple"
                ))

    def draw(self):
        self._sprite_list.draw(pixelated=True)
        for segment in self._geometry_segments:
            segment.draw()

    def move(self, move_distance: numpy.ndarray, rotate_angle: float = 0):
        self._position = self._position + move_distance
        self._rotation_angle = self._rotation_angle + rotate_angle
        for segment in self._geometry_segments:
            segment.move(self._position, move_distance, rotate_angle=rotate_angle)
        for sprite in self._sprite_list:
            new_position = numpy.array([sprite.center_x, sprite.center_y]) + move_distance
            new_position = util.rotate_around_center(self._position, new_position, rotate_angle)
            sprite.center_x, sprite.center_y = new_position[0], new_position[1]
            sprite.radians += rotate_angle

    def distance_squared_to_center(self, point_x, point_y):
        return util.distance_squared_ordered_pair(self._position, point_x, point_y)

    def check_collision(self, sprite: arcade.Sprite):
        return sprite.collides_with_list(self._sprite_list)



class Wall(WorldObject):
    def __init__(self, position: numpy.ndarray, dimensions: numpy.ndarray, rotation_angle: float):
        super().__init__(position, dimensions, rotation_angle, util.WALL_SPRITE_INFO)



class Mirror(WorldObject):
    def __init__(self, position: numpy.ndarray, rotation_angle: float):
        super().__init__(position, numpy.ones(2), rotation_angle, util.MIRROR_SPRITE_INFO, is_interactable=True)
        self._geometry_segments[0].is_reflective = True
        self._geometry_segments[2].is_reflective = True



class LightReceiver(WorldObject):
    def __init__(self, position: numpy.ndarray, rotation_angle: float):
        super().__init__(position, numpy.ones(2), rotation_angle, util.RECEIVER_SPRITE_INFO, is_receiver=True)
        self.charge = 0

    def draw(self):
        color = self.charge / util.RECEIVER_THRESHOLD
        color = min(color*255, 255)
        for sprite in self._sprite_list:
            sprite.color = (color, color, 70)
        super().draw()



class LightSource(WorldObject):
    def __init__(self, position: numpy.ndarray, rotation_angle: float, sprite_info: tuple):
        super().__init__(position, numpy.ones(2), rotation_angle, sprite_info)
        self._light_rays = [light.LightRay(numpy.zeros(2), numpy.zeros(2)) for _ in range(util.NUM_LIGHT_RAYS)]
        self._geometry_segments = []  # TODO: do this better, don't just overwrite to get rid of geometry

    def cast_rays(self, world_objects):
        for ray in self._light_rays:
            ray.cast_ray(world_objects)

    def move(self, move_distance: numpy.ndarray, rotate_angle: float = 0):
        super().move(move_distance, rotate_angle)
        self.calculate_light_ray_positions()

    def draw(self):
        for ray in self._light_rays:
            ray.draw()
        super().draw()

    @abstractmethod
    def calculate_light_ray_positions(self):
        pass


class RadialLightSource(LightSource):
    def __init__(self, position: numpy.ndarray, rotation_angle: float, angular_spread: float):
        super().__init__(position, rotation_angle, util.PLACEHOLDER_SPRITE_INFO)
        self._angular_spread = angular_spread
        self.calculate_light_ray_positions()

    def calculate_light_ray_positions(self):
        num_rays = len(self._light_rays)
        for n in range(num_rays):
            ray_angle = (n / num_rays) * (self._rotation_angle - self._angular_spread / 2) + (1 - n / num_rays) * (
                    self._rotation_angle + self._angular_spread / 2)
            ray_direction = numpy.array([math.cos(ray_angle), math.sin(ray_angle)])
            self._light_rays[n]._origin = self._position
            self._light_rays[n]._direction = ray_direction


class ParallelLightSource(LightSource):
    def __init__(self, position: numpy.ndarray, rotation_angle: float):
        super().__init__(position, rotation_angle, util.PLACEHOLDER_SPRITE_INFO)
        self._width = 32
        self.calculate_light_ray_positions()

    def calculate_light_ray_positions(self):
        num_rays = len(self._light_rays)
        ray_direction = numpy.array([math.cos(self._rotation_angle), math.sin(self._rotation_angle)])
        spread_direction = numpy.array(
            [math.cos(self._rotation_angle + numpy.pi / 2), math.sin(self._rotation_angle + numpy.pi / 2)])
        for n in range(-num_rays // 2, num_rays // 2):
            self._light_rays[n]._origin = self._position + ((n / num_rays) * self._width) * spread_direction
            self._light_rays[n]._direction = ray_direction

