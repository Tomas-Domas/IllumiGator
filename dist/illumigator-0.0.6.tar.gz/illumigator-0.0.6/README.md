# IllumiGator
2D Light-Based Puzzle Game

## Google Drive Resources
https://drive.google.com/drive/folders/1HQ1lIxgZJNANgWnts3bsWUUTnnfJrKXW?usp=sharing

(contains timesheet and project ideas)

## Dependencies
arcade
numpy
screeninfo